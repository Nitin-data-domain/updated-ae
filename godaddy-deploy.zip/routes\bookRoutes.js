const express = require('express');
const router = express.Router();
const {
  getBooks,
  getBookOptions,
  downloadBook,
  serveBookFile,
  getAllBooks,
  createBook,
  updateBook,
  deleteBook,
} = require('../controllers/bookController');
const { protect } = require('../middleware/auth');
const { uploadBook } = require('../middleware/upload');

// Public routes
router.get('/', getBooks);
router.get('/options', getBookOptions);
router.get('/download/:id', downloadBook);
router.head('/download/:id', downloadBook);
router.get('/file/:id', serveBookFile);
router.head('/file/:id', serveBookFile);
router.get('/view/:id', serveBookFile);
router.head('/view/:id', serveBookFile);

// Admin routes
router.get('/admin', protect, getAllBooks);
router.post('/', protect, uploadBook.single('file'), createBook);
router.put('/:id', protect, uploadBook.single('file'), updateBook);
router.delete('/:id', protect, deleteBook);

module.exports = router;
